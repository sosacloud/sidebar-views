import styled from 'styled-components';


const RelatedTrackList = styled.ul`
  padding: 0;
  margin: 0;
  display: block;
  list-style: none;
  text-align: left;
`;

export default RelatedTrackList;